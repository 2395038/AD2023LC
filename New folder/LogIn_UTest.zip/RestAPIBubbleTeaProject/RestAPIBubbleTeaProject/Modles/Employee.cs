﻿using System.Numerics;


namespace RestAPIBubbleTeaProject.Modles
{
    public class Employee
    {
        public string emp_id { get; set; }
        public string emp_fname { get; set; }
        public string emp_lname { get; set; }
        public string emp_email { get; set; }
        public long emp_phone { get; set; }
        public string emp_dept { get; set; }
        public string emp_password { get; set; }

    }
}
