﻿using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Data;
namespace RestAPIBubbleTeaProject.Controllers
{
    public class EmplyeeController : ControllerBase
    {
        
    }
}
