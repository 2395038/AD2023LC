﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFBubbleTeaProject.Moddle
{
    internal class Employee
    {
        public string emp_id { get; set; }
        public string emp_fname { get; set; }
        public string emp_lname { get; set; }
        public string emp_email { get; set; }
        public long emp_phone { get; set; }
        public string emp_dept { get; set; }
        public string emp_password { get; set; }
    }
}
