using LogIn_UnitTest; 
namespace LogIn_NunitTest
{
    public class Tests
    {
        private UserAuthentication logIn;
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}